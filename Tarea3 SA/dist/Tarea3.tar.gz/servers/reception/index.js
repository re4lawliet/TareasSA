import { receptionServer } from './reception-server'

receptionServer.listen()
receptionServer.start()