import { motoServer } from './moto-server'

motoServer.listen()
motoServer.start()